$(document).ready(function(){
                    $('.navbar-toggle .collapsed').click(function(){
                    	$('.navbar-toggle').toggleClass('active');
                    });
                    $('.navbar-fixed').click(function(){
                        $('.navbar-fixed').toggleClass('menucopy');
                    });
                    $('.slider').slick({
                        dots: true,
                        infinite: true,
                        speed: 900,
                           fade: true,
                            cssEase: 'linear'
                        });
                    
                });